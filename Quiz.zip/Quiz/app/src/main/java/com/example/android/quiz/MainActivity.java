package com.example.android.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int totalPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
//  takes all of the users submitted/filled in/selected answers and evaluates them
    public void submitAnswers(android.view.View view){
        int totalPoints = 0;
        //    checks if the first question is right
        RadioButton firstQuestionAnswer = (RadioButton) findViewById(R.id.first_question_correct_radio_button_option);
        if(firstQuestionAnswer.isChecked()){
            totalPoints++;
        }
        // checks if the second question  right
        CheckBox secondQuestionCorrectOption1 = (CheckBox) findViewById(R.id.second_question_first_check_box_correct_option_one);
        CheckBox secondQuestionCorrectOption2 = (CheckBox) findViewById(R.id.second_question_second_check_box_option_correct_option_two);
        CheckBox secondQuestionThirdOption = (CheckBox) findViewById(R.id.second_question_third_check_box_option);
        CheckBox secondQuestionFourthOption = (CheckBox) findViewById(R.id.second_question_fourth_check_box_option);

//        makees sure that only the right answers are selected
        if(secondQuestionCorrectOption1.isChecked() && secondQuestionCorrectOption2.isChecked() && !secondQuestionThirdOption.isChecked() && !secondQuestionFourthOption.isChecked()){
            totalPoints++;
        }
        //    checks if the third question's answer is right
        EditText thirdQuestion = (EditText) findViewById(R.id.third_question_answer);
        String thirdQuestionUserInput = thirdQuestion.getText().toString().replaceAll("\\s", "");
        if(thirdQuestionUserInput.equalsIgnoreCase("england")) {
            totalPoints++;
        }
        else {
            totalPoints += 0;
        }
//        checks if the fourths question's answer is right
        RadioButton fourthQuestionAnswer = (RadioButton) findViewById(R.id.fourth_question_first_option);
        if(fourthQuestionAnswer.isChecked()){
            totalPoints++;
        }
//        finally evaluates the totalPoints and give the respective Score

        if(totalPoints==0){
            Toast.makeText(getApplicationContext(), "You got a 0%",
                    Toast.LENGTH_SHORT).show();
        }
        else if(totalPoints==1){
            Toast.makeText(getApplicationContext(), "You got a 25%",
                    Toast.LENGTH_SHORT).show();
        }
        else if(totalPoints==2){
            Toast.makeText(getApplicationContext(), "You got a 50%",
                    Toast.LENGTH_SHORT).show();
        }
        else if(totalPoints==3){
            Toast.makeText(getApplicationContext(), "You got a 75%",
                    Toast.LENGTH_SHORT).show();
        }
        else if(totalPoints==4){
            Toast.makeText(getApplicationContext(), "You got a 100! Good Job!",
                    Toast.LENGTH_SHORT).show();
        }
    }

//    resets answers
    public void resetAnswers(android.view.View view){
//        resets points
        totalPoints=0;
//        clears any options selected in the RadioGroup(first question)
        RadioGroup radioGroup1 = (RadioGroup) findViewById(R.id.first_question_radio_button_options);
        radioGroup1.clearCheck();
//        clears any options selected in the LinearLayout containing check boxes
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.second_question_first_check_box_correct_option_one);
        checkBox1.setChecked(false);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.second_question_second_check_box_option_correct_option_two);
        checkBox2.setChecked(false);
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.second_question_third_check_box_option);
        checkBox3.setChecked(false);
        CheckBox checkBox4 = (CheckBox) findViewById(R.id.second_question_fourth_check_box_option);
        checkBox4.setChecked(false);
//        clears any text/letter written in the EditText widget
        EditText editTextAnswer = (EditText) findViewById(R.id.third_question_answer);
        editTextAnswer.setText("");
//        clears any options selected in the RadioGroup(fourth question)
        RadioGroup radioGroup4 = (RadioGroup) findViewById(R.id.fourth_question_radio_button_options);
        radioGroup4.clearCheck();
//        resets scoreDisplay
        Toast.makeText(getApplicationContext(), "Quiz has been reset",
                Toast.LENGTH_SHORT).show();
    }
}